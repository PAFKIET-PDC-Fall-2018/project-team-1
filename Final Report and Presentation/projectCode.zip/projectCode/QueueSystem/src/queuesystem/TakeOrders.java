
package queuesystem;
import java.io.RandomAccessFile;
import java.util.Properties;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.IOException;
import javax.swing.JOptionPane;

/** ** @author acer-PC */

public class TakeOrders extends javax.swing.JFrame {
    
    int numberOfProst ;
    int numberOfFries ;
    int numberOfNugget;
    int numberOfChrimp;
    int numberOfSandwich;
    int numberOfCorn;
    
    
    int NodeNumber ;// number of Machine from 1 to 6 cont .........
    int InvoiceNumberStart ; // start number of invoice 
    int InvoiceNumberEnd;
    int numberOf_Meals; // number of meal showin on the screen from 1 to 6 cont ......
    
    String Meal1;
    String Meal2;
    String Meal3;
    String Meal4;
    String Meal5;
    String Meal6;
    String Restaurant_Name;
    String  food1="";
    
   public void restCounter (){
   // Counters of The Meals
       numberOfProst = 0;
       numberOfFries=0;
       numberOfNugget=0;
       numberOfChrimp=0;
       numberOfSandwich=0;
       numberOfCorn=0;
         ProstCounter.setText(Integer.toString(numberOfProst));
         FriseCounter.setText(Integer.toString(numberOfFries));
         NuggetsCounter.setText(Integer.toString(numberOfNugget));
         ChrimpCounter.setText(Integer.toString(numberOfChrimp));
         SandwichCounter.setText(Integer.toString(numberOfSandwich));
         CornCounter.setText(Integer.toString(numberOfCorn));
   }
    
    
    public TakeOrders() {
        
        this.numberOfProst = 0;
        this.numberOfFries=0;
        this.numberOfNugget=0;
        this.numberOfChrimp=0;
        this.numberOfSandwich=0;
        this.numberOfCorn=0;
        
        initComponents();
        Properties prop = new Properties();
        InputStream inp ;
        
        try {
            inp=new FileInputStream("/home/isra/Documents/Study/PDC/Distributed Systems Development using MPI-20181209T155157Z-001/Distributed Systems Development using MPI/projectCode/QueueSystem/src/ConfigFiles/Config.txt");
            prop.load(inp);
            numberOf_Meals=Integer.parseInt(prop.getProperty("numberOfMeals"));
            
            NodeNumber = Integer.parseInt(prop.getProperty("Node_Number"));
            Restaurant_Name=prop.getProperty("RestaurantName");
            Meal1=prop.getProperty("Meal_1");
            Meal2=prop.getProperty("Meal_2");
            Meal3=prop.getProperty("Meal_3");
            Meal4=prop.getProperty("Meal_4");
            Meal5=prop.getProperty("Meal_5");
            Meal6=prop.getProperty("Meal_6");
            
            
        } catch (IOException ex) { 
            ex.printStackTrace();
        }
        
         TakeOrdeLabel.setText(Restaurant_Name);
         ProstPic.setVisible(false);
         AddProst.setVisible(false);
         SubProst.setVisible(false);
         ProstLabel.setVisible(false);
         ProstCounter.setVisible(false);
         
         FriesPic.setVisible(false);
         SubFries.setVisible(false);
         AddFries.setVisible(false);
         FrizeLabel.setVisible(false);
         FriseCounter.setVisible(false);
         
         NuggetPic.setVisible(false);
         AddNugget.setVisible(false);
         SubNugget.setVisible(false);
         NuggetsLabel.setVisible(false);
         NuggetsCounter.setVisible(false);
                 
         ChrimpPic.setVisible(false);
         AddChrimp.setVisible(false);
         SubChrimp.setVisible(false);
         ChrimpLabel.setVisible(false);
         ChrimpCounter.setVisible(false);
         
         SasdwichcPic.setVisible(false);
         AddSasdwich.setVisible(false);
         SubSasdwich.setVisible(false);
         SandwichLabel.setVisible(false);
         SandwichCounter.setVisible(false);
         
         CornPic.setVisible(false);
         AddCorn.setVisible(false);
         SubCorn.setVisible(false);
         CornLabel.setVisible(false);
         CornCounter.setVisible(false);
         
         
         switch(numberOf_Meals){
             case 1:
                 ProstPic.setVisible(true);
                 AddProst.setVisible(true);
                 SubProst.setVisible(true);
                 ProstLabel.setVisible(true);
                 ProstCounter.setVisible(true);
                 break;
                 
             case 2:
                    ProstPic.setVisible(true);
                    AddProst.setVisible(true);
                    SubProst.setVisible(true);
                    ProstLabel.setVisible(true);

         
                    FriesPic.setVisible(true);
                    SubFries.setVisible(true);
                    AddFries.setVisible(true);
                    FrizeLabel.setVisible(true);
                    break;
             case 3:
                    ProstPic.setVisible(true);
                    AddProst.setVisible(true);
                    SubProst.setVisible(true);
                    ProstLabel.setVisible(true);
         
                    FriesPic.setVisible(true);
                    SubFries.setVisible(true);
                    AddFries.setVisible(true);
                    FrizeLabel.setVisible(true);
                 
                    NuggetPic.setVisible(true);
                    AddNugget.setVisible(true);
                    SubNugget.setVisible(true);
                    NuggetsLabel.setVisible(true);
                    break;
                    
             case 4:
                   ProstPic.setVisible(true);
                    AddProst.setVisible(true);
                    SubProst.setVisible(true);
                    ProstLabel.setVisible(true);
         
                    FriesPic.setVisible(true);
                    SubFries.setVisible(true);
                    AddFries.setVisible(true);
                    FrizeLabel.setVisible(true);
                 
                    NuggetPic.setVisible(true);
                    AddNugget.setVisible(true);
                    SubNugget.setVisible(true);
                    NuggetsLabel.setVisible(true);
                 
                    ChrimpPic.setVisible(true);
                    AddChrimp.setVisible(true);
                    SubChrimp.setVisible(true);
                    ChrimpLabel.setVisible(true);
                 break;
                 
             case 5:
                    ProstPic.setVisible(true);
                    AddProst.setVisible(true);
                    SubProst.setVisible(true);
                    ProstLabel.setVisible(true);
                    ProstCounter.setVisible(true);
         
                    FriesPic.setVisible(true);
                    SubFries.setVisible(true);
                    AddFries.setVisible(true);
                    FrizeLabel.setVisible(true);
                    FriseCounter.setVisible(true);
         
                    NuggetPic.setVisible(true);
                    AddNugget.setVisible(true);
                    SubNugget.setVisible(true);
                    NuggetsLabel.setVisible(true);
                    NuggetsCounter.setVisible(true);
                 
                    ChrimpPic.setVisible(true);
                    AddChrimp.setVisible(true);
                    SubChrimp.setVisible(true);
                    ChrimpLabel.setVisible(true);
                    ChrimpCounter.setVisible(true);
         
                    SasdwichcPic.setVisible(true);
                    AddSasdwich.setVisible(true);
                    SubSasdwich.setVisible(true);
                    SandwichLabel.setVisible(true);
                    SandwichCounter.setVisible(true);
                 break;
                 
             case 6:
                 ProstPic.setVisible(true);
                    AddProst.setVisible(true);
                    SubProst.setVisible(true);
                    ProstLabel.setVisible(true);
                    ProstCounter.setVisible(true);
         
                    FriesPic.setVisible(true);
                    SubFries.setVisible(true);
                    AddFries.setVisible(true);
                    FrizeLabel.setVisible(true);
                    FriseCounter.setVisible(true);
         
                    NuggetPic.setVisible(true);
                    AddNugget.setVisible(true);
                    SubNugget.setVisible(true);
                    NuggetsLabel.setVisible(true);
                    NuggetsCounter.setVisible(true);
                 
                    ChrimpPic.setVisible(true);
                    AddChrimp.setVisible(true);
                    SubChrimp.setVisible(true);
                    ChrimpLabel.setVisible(true);
                    ChrimpCounter.setVisible(true);
         
                    SasdwichcPic.setVisible(true);
                    AddSasdwich.setVisible(true);
                    SubSasdwich.setVisible(true);
                    SandwichLabel.setVisible(true);
                    SandwichCounter.setVisible(true);
                    
                    CornPic.setVisible(true);
                    AddCorn.setVisible(true);
                    SubCorn.setVisible(true);
                    CornLabel.setVisible(true);
                    CornCounter.setVisible(true);
                 break;
                    
                    
             default:
                 
                 
                 break;
         
         }
         
         
         switch(NodeNumber){
         
             case 1:
                 InvoiceNumberStart=100;
                 InvoiceNumberEnd=199;
                 break;
                 
             case 2:
                 InvoiceNumberStart=200;
                 InvoiceNumberEnd=299;
                 break;
                 
             case 3:
                 InvoiceNumberStart=300;
                 InvoiceNumberEnd=399;
                 break;
                 
             case 4:
                 InvoiceNumberStart=400;
                 InvoiceNumberEnd=499;
                 break;
                 
             case 5:
                 InvoiceNumberStart=500;
                 InvoiceNumberEnd=599;
                 break;
                 
             case 6:
                 InvoiceNumberStart=600;
                 InvoiceNumberEnd=699;
                 break;
                 
             default :
                 
                 break ;
         
         }
         
        
         
         
    }//constractor

  
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        ProstCounter = new javax.swing.JLabel();
        FriseCounter = new javax.swing.JLabel();
        NuggetsCounter = new javax.swing.JLabel();
        ChrimpCounter = new javax.swing.JLabel();
        SandwichCounter = new javax.swing.JLabel();
        CornCounter = new javax.swing.JLabel();
        ProstLabel = new javax.swing.JLabel();
        FrizeLabel = new javax.swing.JLabel();
        NuggetsLabel = new javax.swing.JLabel();
        ChrimpLabel = new javax.swing.JLabel();
        SandwichLabel = new javax.swing.JLabel();
        CornLabel = new javax.swing.JLabel();
        AddProst = new javax.swing.JButton();
        SubProst = new javax.swing.JButton();
        ProstPic = new javax.swing.JLabel();
        SubFries = new javax.swing.JButton();
        AddFries = new javax.swing.JButton();
        FriesPic = new javax.swing.JLabel();
        AddNugget = new javax.swing.JButton();
        SubNugget = new javax.swing.JButton();
        NuggetPic = new javax.swing.JLabel();
        AddChrimp = new javax.swing.JButton();
        SubChrimp = new javax.swing.JButton();
        ChrimpPic = new javax.swing.JLabel();
        AddSasdwich = new javax.swing.JButton();
        SubSasdwich = new javax.swing.JButton();
        SasdwichcPic = new javax.swing.JLabel();
        SubCorn = new javax.swing.JButton();
        AddCorn = new javax.swing.JButton();
        CornPic = new javax.swing.JLabel();
        CreateOrder = new javax.swing.JButton();
        Cancel = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        INVOICE = new javax.swing.JTextArea();
        TakeOrdeLabel = new javax.swing.JLabel();
        BackGround = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(null);

        ProstCounter.setFont(new java.awt.Font("Tahoma", 3, 36)); // NOI18N
        ProstCounter.setForeground(new java.awt.Color(255, 255, 255));
        ProstCounter.setText("0");
        jPanel1.add(ProstCounter);
        ProstCounter.setBounds(240, 40, 110, 30);

        FriseCounter.setFont(new java.awt.Font("Tahoma", 3, 36)); // NOI18N
        FriseCounter.setForeground(new java.awt.Color(255, 255, 255));
        FriseCounter.setText("0");
        FriseCounter.setToolTipText("");
        jPanel1.add(FriseCounter);
        FriseCounter.setBounds(660, 40, 100, 30);

        NuggetsCounter.setFont(new java.awt.Font("Tahoma", 3, 36)); // NOI18N
        NuggetsCounter.setForeground(new java.awt.Color(255, 255, 255));
        NuggetsCounter.setText("0");
        jPanel1.add(NuggetsCounter);
        NuggetsCounter.setBounds(1030, 50, 80, 30);

        ChrimpCounter.setFont(new java.awt.Font("Tahoma", 3, 36)); // NOI18N
        ChrimpCounter.setForeground(new java.awt.Color(255, 255, 255));
        ChrimpCounter.setText("0");
        jPanel1.add(ChrimpCounter);
        ChrimpCounter.setBounds(230, 280, 120, 43);

        SandwichCounter.setFont(new java.awt.Font("Tahoma", 3, 36)); // NOI18N
        SandwichCounter.setForeground(new java.awt.Color(255, 255, 255));
        SandwichCounter.setText("0");
        jPanel1.add(SandwichCounter);
        SandwichCounter.setBounds(680, 300, 110, 43);

        CornCounter.setFont(new java.awt.Font("Tahoma", 3, 36)); // NOI18N
        CornCounter.setForeground(new java.awt.Color(255, 255, 255));
        CornCounter.setText("0");
        jPanel1.add(CornCounter);
        CornCounter.setBounds(1040, 300, 90, 40);

        ProstLabel.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        ProstLabel.setForeground(new java.awt.Color(255, 255, 255));
        ProstLabel.setText("PROSTED");
        jPanel1.add(ProstLabel);
        ProstLabel.setBounds(40, 40, 160, 30);

        FrizeLabel.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        FrizeLabel.setForeground(new java.awt.Color(255, 255, 255));
        FrizeLabel.setText("Frise");
        jPanel1.add(FrizeLabel);
        FrizeLabel.setBounds(490, 40, 80, 29);

        NuggetsLabel.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        NuggetsLabel.setForeground(new java.awt.Color(255, 255, 255));
        NuggetsLabel.setText("Nuggets");
        jPanel1.add(NuggetsLabel);
        NuggetsLabel.setBounds(880, 50, 120, 29);

        ChrimpLabel.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        ChrimpLabel.setForeground(new java.awt.Color(255, 255, 255));
        ChrimpLabel.setText("Chrimp");
        jPanel1.add(ChrimpLabel);
        ChrimpLabel.setBounds(40, 290, 120, 29);

        SandwichLabel.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        SandwichLabel.setForeground(new java.awt.Color(255, 255, 255));
        SandwichLabel.setText("chicken Sandwich");
        jPanel1.add(SandwichLabel);
        SandwichLabel.setBounds(440, 310, 240, 29);

        CornLabel.setBackground(new java.awt.Color(0, 0, 0));
        CornLabel.setFont(new java.awt.Font("Tahoma", 3, 28)); // NOI18N
        CornLabel.setForeground(new java.awt.Color(255, 255, 255));
        CornLabel.setText("Corn");
        jPanel1.add(CornLabel);
        CornLabel.setBounds(860, 310, 80, 22);

        AddProst.setBackground(new java.awt.Color(204, 204, 204));
        AddProst.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        AddProst.setText("+");
        AddProst.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddProstActionPerformed(evt);
            }
        });
        jPanel1.add(AddProst);
        AddProst.setBounds(220, 130, 70, 70);

        SubProst.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        SubProst.setText("-");
        SubProst.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SubProstActionPerformed(evt);
            }
        });
        jPanel1.add(SubProst);
        SubProst.setBounds(30, 130, 70, 70);

        ProstPic.setIcon(new javax.swing.ImageIcon(getClass().getResource("/queuesystem/Pics/ProstChiken.jpg"))); // NOI18N
        ProstPic.setText("jLabel1");
        jPanel1.add(ProstPic);
        ProstPic.setBounds(30, 70, 260, 200);

        SubFries.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        SubFries.setText("-");
        SubFries.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SubFriesActionPerformed(evt);
            }
        });
        jPanel1.add(SubFries);
        SubFries.setBounds(450, 120, 70, 70);

        AddFries.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        AddFries.setText("+");
        AddFries.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddFriesActionPerformed(evt);
            }
        });
        jPanel1.add(AddFries);
        AddFries.setBounds(640, 120, 70, 70);

        FriesPic.setIcon(new javax.swing.ImageIcon(getClass().getResource("/queuesystem/Pics/Fries.jpg"))); // NOI18N
        FriesPic.setText("FriesPic");
        FriesPic.setToolTipText("");
        FriesPic.setMaximumSize(new java.awt.Dimension(400, 300));
        FriesPic.setMinimumSize(new java.awt.Dimension(400, 300));
        FriesPic.setPreferredSize(new java.awt.Dimension(400, 300));
        jPanel1.add(FriesPic);
        FriesPic.setBounds(450, 70, 260, 200);

        AddNugget.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        AddNugget.setText("+");
        AddNugget.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddNuggetActionPerformed(evt);
            }
        });
        jPanel1.add(AddNugget);
        AddNugget.setBounds(1030, 140, 70, 70);

        SubNugget.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        SubNugget.setText("-");
        SubNugget.setMaximumSize(new java.awt.Dimension(53, 37));
        SubNugget.setMinimumSize(new java.awt.Dimension(53, 37));
        SubNugget.setPreferredSize(new java.awt.Dimension(53, 37));
        SubNugget.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SubNuggetActionPerformed(evt);
            }
        });
        jPanel1.add(SubNugget);
        SubNugget.setBounds(850, 140, 70, 70);

        NuggetPic.setIcon(new javax.swing.ImageIcon(getClass().getResource("/queuesystem/Pics/Nuggets.JPG"))); // NOI18N
        NuggetPic.setText("Nuggets");
        NuggetPic.setMaximumSize(new java.awt.Dimension(400, 400));
        NuggetPic.setMinimumSize(new java.awt.Dimension(400, 400));
        NuggetPic.setPreferredSize(new java.awt.Dimension(400, 400));
        jPanel1.add(NuggetPic);
        NuggetPic.setBounds(850, 80, 260, 200);

        AddChrimp.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        AddChrimp.setText("+");
        AddChrimp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddChrimpActionPerformed(evt);
            }
        });
        jPanel1.add(AddChrimp);
        AddChrimp.setBounds(220, 380, 70, 70);

        SubChrimp.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        SubChrimp.setText("-");
        SubChrimp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SubChrimpActionPerformed(evt);
            }
        });
        jPanel1.add(SubChrimp);
        SubChrimp.setBounds(30, 380, 70, 70);

        ChrimpPic.setIcon(new javax.swing.ImageIcon(getClass().getResource("/queuesystem/Pics/Shrimp.jpg"))); // NOI18N
        ChrimpPic.setText("jLabel1");
        jPanel1.add(ChrimpPic);
        ChrimpPic.setBounds(30, 320, 260, 200);

        AddSasdwich.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        AddSasdwich.setText("+");
        AddSasdwich.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddSasdwichActionPerformed(evt);
            }
        });
        jPanel1.add(AddSasdwich);
        AddSasdwich.setBounds(640, 390, 70, 70);

        SubSasdwich.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        SubSasdwich.setText("-");
        SubSasdwich.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SubSasdwichActionPerformed(evt);
            }
        });
        jPanel1.add(SubSasdwich);
        SubSasdwich.setBounds(450, 390, 70, 70);

        SasdwichcPic.setIcon(new javax.swing.ImageIcon(getClass().getResource("/queuesystem/Pics/chickenSandwich.jpg"))); // NOI18N
        SasdwichcPic.setText("jLabel2");
        jPanel1.add(SasdwichcPic);
        SasdwichcPic.setBounds(450, 340, 260, 170);

        SubCorn.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        SubCorn.setText("-");
        SubCorn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SubCornActionPerformed(evt);
            }
        });
        jPanel1.add(SubCorn);
        SubCorn.setBounds(850, 400, 70, 70);

        AddCorn.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        AddCorn.setText("+");
        AddCorn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddCornActionPerformed(evt);
            }
        });
        jPanel1.add(AddCorn);
        AddCorn.setBounds(1030, 400, 70, 70);

        CornPic.setIcon(new javax.swing.ImageIcon(getClass().getResource("/queuesystem/Pics/Corn.jpg"))); // NOI18N
        CornPic.setText("jLabel1");
        jPanel1.add(CornPic);
        CornPic.setBounds(850, 340, 250, 200);

        CreateOrder.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        CreateOrder.setText("Create Order");
        CreateOrder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CreateOrderActionPerformed(evt);
            }
        });
        jPanel1.add(CreateOrder);
        CreateOrder.setBounds(600, 550, 130, 30);

        Cancel.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        Cancel.setText("Cancel Order");
        Cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelActionPerformed(evt);
            }
        });
        jPanel1.add(Cancel);
        Cancel.setBounds(270, 550, 140, 30);

        INVOICE.setColumns(20);
        INVOICE.setRows(5);
        jScrollPane2.setViewportView(INVOICE);

        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(420, 520, 170, 190);

        TakeOrdeLabel.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        TakeOrdeLabel.setForeground(new java.awt.Color(240, 240, 240));
        TakeOrdeLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TakeOrdeLabel.setText("Take Orders");
        jPanel1.add(TakeOrdeLabel);
        TakeOrdeLabel.setBounds(420, 0, 320, 40);

        BackGround.setIcon(new javax.swing.ImageIcon(getClass().getResource("/queuesystem/Pics/Rest3.jpg"))); // NOI18N
        jPanel1.add(BackGround);
        BackGround.setBounds(-50, 0, 1230, 814);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1500, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 814, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AddProstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddProstActionPerformed
                
        numberOfProst++;
        ProstCounter.setText(Integer.toString(numberOfProst));
       
        
        
    }//GEN-LAST:event_AddProstActionPerformed

    private void SubProstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SubProstActionPerformed
          
        numberOfProst--;
        if(numberOfProst<0){
        numberOfProst=0;
        }
         ProstCounter.setText(Integer.toString(numberOfProst));
       
    }//GEN-LAST:event_SubProstActionPerformed

    private void AddFriesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddFriesActionPerformed
        numberOfFries++;
        FriseCounter.setText(Integer.toString(numberOfFries));
        
    }//GEN-LAST:event_AddFriesActionPerformed

    private void SubFriesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SubFriesActionPerformed
       numberOfFries--;
        if(numberOfFries<0){
        numberOfFries=0;
        }
         FriseCounter.setText(Integer.toString(numberOfFries));
        
      
    }//GEN-LAST:event_SubFriesActionPerformed

    private void SubNuggetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SubNuggetActionPerformed
        numberOfNugget--;
        
        if(numberOfNugget<0){
        numberOfNugget=0;
        }   
         NuggetsCounter.setText(Integer.toString(numberOfNugget));

    }//GEN-LAST:event_SubNuggetActionPerformed

    private void AddChrimpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddChrimpActionPerformed
        numberOfChrimp++;
           ChrimpCounter.setText(Integer.toString(numberOfChrimp));
    }//GEN-LAST:event_AddChrimpActionPerformed

    private void AddSasdwichActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddSasdwichActionPerformed
            numberOfSandwich++;
            SandwichCounter.setText(Integer.toString(numberOfSandwich));
    }//GEN-LAST:event_AddSasdwichActionPerformed

    private void AddNuggetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddNuggetActionPerformed
            numberOfNugget++;
            NuggetsCounter.setText(Integer.toString(numberOfNugget));
            
    }//GEN-LAST:event_AddNuggetActionPerformed

    private void SubChrimpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SubChrimpActionPerformed
        numberOfChrimp--;
        
        if(numberOfChrimp<0){
        numberOfChrimp=0;
        }   
         ChrimpCounter.setText(Integer.toString(numberOfChrimp));

    }//GEN-LAST:event_SubChrimpActionPerformed

    private void SubSasdwichActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SubSasdwichActionPerformed
        numberOfSandwich--;
        
        if(numberOfSandwich<0){
        numberOfSandwich=0;
        }   
         SandwichCounter.setText(Integer.toString(numberOfSandwich));
    }//GEN-LAST:event_SubSasdwichActionPerformed

    private void SubCornActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SubCornActionPerformed
                numberOfCorn--;
                if(numberOfCorn<0){
        numberOfCorn=0;
        }   
         CornCounter.setText(Integer.toString(numberOfCorn));
    }//GEN-LAST:event_SubCornActionPerformed

    private void AddCornActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddCornActionPerformed
       
        numberOfCorn++;
        CornCounter.setText(Integer.toString(numberOfCorn));
    }//GEN-LAST:event_AddCornActionPerformed

    private void CreateOrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CreateOrderActionPerformed
        
        if(numberOfProst == 0 && numberOfFries == 0 && numberOfNugget == 0 && numberOfChrimp == 0 && numberOfSandwich == 0&& numberOfCorn == 0){
                JOptionPane.showMessageDialog(null, "You Shold Select One Item At Least");
            }
        else{
            
        int CreateOrder= JOptionPane.showConfirmDialog(null,"Do You Realy Want to Create Order","Create Order",JOptionPane.YES_NO_OPTION);
        if(CreateOrder==0){
            if(InvoiceNumberStart == InvoiceNumberEnd){
            InvoiceNumberStart = InvoiceNumberEnd-99;
            }
                    InvoiceNumberStart++;
                    food1="";
                            
       food1+=" NO:        " +InvoiceNumberStart +"\n\n"; 
       String Meal_1=Meal1+" "+numberOfProst+"\n";
       String Meal_2=Meal2+" "+numberOfFries+"\n";
       String Meal_3=Meal3+" "+numberOfNugget+"\n";
       String Meal_4=Meal4+" "+numberOfChrimp+"\n";
       String Meal_5=Meal5+" "+numberOfSandwich+"\n";
       String Meal_6=Meal6+" "+numberOfCorn+"\n";
        
        if(numberOfProst>0){
        food1+= Meal_1;
        }
        
        if(numberOfFries>0){
        food1+= Meal_2;
        }
        
        if(numberOfNugget>0){
        food1+= Meal_3;
        }
        
        if(numberOfChrimp>0){
        food1+= Meal_4;
        }
        
        if(numberOfSandwich>0){
        food1+= Meal_5;
        }
        
        if(numberOfCorn>0){
        food1+= Meal_6;
        }
        
        INVOICE.setText(food1);
        INVOICE.setEditable(false);
        
        System.out.println(food1);
            try {
             // Connect to the named pipe
                    RandomAccessFile pipe = new RandomAccessFile("/home/isra/Documents/Study/PDC/Distributed Systems Development using MPI-20181209T155157Z-001/Distributed Systems Development using MPI/projectCode/QueueSystem/FifoFile", "rw");
 
                    String req = food1;
                    // Write request to the pipe
                    pipe.writeBytes(req); //step1
                     
                     // Close the pipe
                    pipe.close();
 
              // do something with res
             }
            catch (Exception e) {
                  System.out.println("ERROR");
            }
        
                restCounter();
        }
            else{
                JOptionPane.showMessageDialog(null, "Order Cnceled");
                 
            }
            
       
        
        }
    }//GEN-LAST:event_CreateOrderActionPerformed

    private void CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelActionPerformed
        if(numberOfProst == 0 && numberOfFries == 0 && numberOfNugget == 0 && numberOfChrimp == 0 && numberOfSandwich == 0&& numberOfCorn == 0){
                JOptionPane.showMessageDialog(null, "No Orders");
            }
        else{
        int CancelOrder= JOptionPane.showConfirmDialog(null,"Do You Realy Want to Cancel Order","Cancel Order",JOptionPane.YES_NO_OPTION);
        if(CancelOrder==0){
        restCounter();
        }
        else{
        
        }
    }
    }//GEN-LAST:event_CancelActionPerformed
        
        
  

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddChrimp;
    private javax.swing.JButton AddCorn;
    private javax.swing.JButton AddFries;
    private javax.swing.JButton AddNugget;
    private javax.swing.JButton AddProst;
    private javax.swing.JButton AddSasdwich;
    private javax.swing.JLabel BackGround;
    private javax.swing.JButton Cancel;
    private javax.swing.JLabel ChrimpCounter;
    private javax.swing.JLabel ChrimpLabel;
    private javax.swing.JLabel ChrimpPic;
    private javax.swing.JLabel CornCounter;
    private javax.swing.JLabel CornLabel;
    private javax.swing.JLabel CornPic;
    private javax.swing.JButton CreateOrder;
    private javax.swing.JLabel FriesPic;
    private javax.swing.JLabel FriseCounter;
    private javax.swing.JLabel FrizeLabel;
    private javax.swing.JTextArea INVOICE;
    private javax.swing.JLabel NuggetPic;
    private javax.swing.JLabel NuggetsCounter;
    private javax.swing.JLabel NuggetsLabel;
    private javax.swing.JLabel ProstCounter;
    private javax.swing.JLabel ProstLabel;
    private javax.swing.JLabel ProstPic;
    private javax.swing.JLabel SandwichCounter;
    private javax.swing.JLabel SandwichLabel;
    private javax.swing.JLabel SasdwichcPic;
    private javax.swing.JButton SubChrimp;
    private javax.swing.JButton SubCorn;
    private javax.swing.JButton SubFries;
    private javax.swing.JButton SubNugget;
    private javax.swing.JButton SubProst;
    private javax.swing.JButton SubSasdwich;
    private javax.swing.JLabel TakeOrdeLabel;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
