
package queuesystem;


public class QueueSystem {

  
    public static void main(String[] args) {
       
        TakeOrders Obj = new TakeOrders();
        Obj.setVisible(true);
        
    }
    
}
