#include <fcntl.h>
#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>
#include <mpi.h>
#include <string.h>
#include <pthread.h>
#include <omp.h>
#define MAX_BUF 1024

//void *functionOfThread(void * parm);

int main(int argv, char *argc[])
{
    FILE *fptr;
    int myrank, process, err;
    int fd,fd1,fd2,fd3;
   
    

    char buf[MAX_BUF];

    err = MPI_Init(&argv, &argc);




    /* open, read, and display the message from the FIFO */

    while(1)
    {


        int length;
        int rc;
        err = MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
        err = MPI_Comm_size(MPI_COMM_WORLD, &process);
	//printf("myid, %d",myrank);

        if(myrank==0)
        {

           
        }
        else if(myrank==1)
        {
	    printf("myid %d,",myrank);
           
           }     


                /*
                	    pthread_t tid;
                            pthread_create(&tid,NULL,functionOfThread,NULL);
                */


            // paraalesm
        
    
    else
    {



    }

}//endOfOuterLoop
err =MPI_Finalize();
return 0;
}



