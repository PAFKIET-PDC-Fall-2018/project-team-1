#include <fcntl.h>
#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>
#include <mpi.h>
#include <string.h>
#include <pthread.h>
#include <omp.h>
#define MAX_BUF 1024

//void *functionOfThread(void * parm);

int main(int argv, char *argc[])
{
    FILE *fptr;
    int myrank, process, err;
    int fd,fd1,fd2,fd3;
    char * myfifo = "/home/isra/Documents/Study/PDC/Distributed Systems Development using MPI-20181209T155157Z-001/Distributed Systems Development using MPI/projectCode/QueueSystem/FifoFile";
    char * myfifo1 = "/home/isra/Documents/Study/PDC/Distributed Systems Development using MPI-20181209T155157Z-001/Distributed Systems Development using MPI/projectCode/QueueSystem/writefifo";
    char * myfifo2 = "/home/isra/Documents/Study/PDC/Distributed Systems Development using MPI-20181209T155157Z-001/Distributed Systems Development using MPI/projectCode/QueueSystem/rwfifio";
    char * myfifo3 = "/home/isra/Documents/Study/PDC/Distributed Systems Development using MPI-20181209T155157Z-001/Distributed Systems Development using MPI/projectCode/QueueSystem/callfifio";
    mkfifo(myfifo, 0666);
    mkfifo(myfifo1, 0666);
    mkfifo(myfifo2, 0666);
    mkfifo(myfifo3, 0666);

    char buf[MAX_BUF];

    err = MPI_Init(&argv, &argc);




    /* open, read, and display the message from the FIFO */

    while(1)
    {


        int length;
        int rc;
        err = MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
        err = MPI_Comm_size(MPI_COMM_WORLD, &process);
	printf("myid, %d",myrank);

        if(myrank==0)
        {

            fd = open(myfifo, O_RDONLY);
            buf[0]=0;
            if((rc = read(fd, buf, MAX_BUF)) > 0)//step2
            {
                buf[rc] = 0;
                printf("Receivedp0: %s\n", buf);
                length= strlen(buf)+1;
                MPI_Send(&length,1, MPI_INT, 1, 1, MPI_COMM_WORLD);//3
                MPI_Send(buf,length,MPI_CHAR,1,0,MPI_COMM_WORLD);
                printf("SIZE: %d \n\n",length);
            }
            close(fd);
        }
        else if(myrank==1)
        {
	    
            #pragma omp parallel num_threads(2)
            {


                //char receve[length];


		int x = omp_get_thread_num();

		if(x == 0){		
                    MPI_Status status;
                    MPI_Recv(&length, 1, MPI_INT, 0, 1, MPI_COMM_WORLD, &status);
                    MPI_Recv(buf,length,MPI_CHAR,0,0,MPI_COMM_WORLD,&status);
		
                    buf[length]=0;
                    printf("P1rec buf = %s \n\n",buf);
                    fd1 = open(myfifo1, O_WRONLY);//4
                    write(fd1, buf, length);
                    close(fd1);
           }     


                /*
                	    pthread_t tid;
                            pthread_create(&tid,NULL,functionOfThread,NULL);
                */

else{
                fd2 = open(myfifo2, O_RDONLY);
                buf[0]=0;

                if((rc = read(fd2, buf, MAX_BUF)) > 0)
                {
                    buf[rc] = 0;
                    printf("Receivedp1 sevd: %s\n", buf);
                    int length= strlen(buf)+1;
                    MPI_Send(&length,1, MPI_INT, 2, 2, MPI_COMM_WORLD);
                    MPI_Send(buf,length,MPI_CHAR,2,3,MPI_COMM_WORLD);
                    printf("SIZE: %d \n\n",length);
                }
                close(fd2);
}
            }// paraalesm
        }
    
    else
    {


        MPI_Status status;
        MPI_Recv(&length, 1, MPI_INT, 1, 2, MPI_COMM_WORLD, &status);
        MPI_Recv(buf,length,MPI_CHAR,1,3,MPI_COMM_WORLD,&status);

        buf[length]=0;

        fd3 = open(myfifo3, O_WRONLY);
        write(fd3, buf, length);
        printf("Receivedp3: %s\n", buf);
        close(fd3);

    }

}//endOfOuterLoop
err =MPI_Finalize();
return 0;
}



